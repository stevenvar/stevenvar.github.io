void buffer_write(int x, int y, int color);
uint8_t buffer_read(int x, int y);
uint8_t buffer_get_byte();
