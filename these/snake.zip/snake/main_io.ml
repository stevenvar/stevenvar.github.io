open Avr

(*** Fonctions du jeu ***)

(** Le tableau qui contient les positions du corps du serpent **)
let max_size = 15
let snake = Array.make max_size (0,0)

(** Teste si le serpent entre en collision avec lui-même *)
exception Lose
let eats_itself head tail =
  let f c = if c = snake.(head) then (raise Lose) in
  try
    if tail < head then
      begin
        for i = tail to head - 1 do
          f snake.(i);
        done
      end
    else
      begin
        for i = tail to max_size - 1 do
          f snake.(i);
        done;
        for i = 0 to head - 1 do
          f snake.(i);
        done;
      end;
    false
  with Lose -> true

(*** Fonctions d'affichage ***)

let draw_snake head tail : unit =
  let (x,y) = snake.(head) in
  let (x',y') = snake.(tail) in
  (* on affiche une nouvelle tête *)
  Oled.draw x y true;
  (* on efface la queue pour donner l'illusion de déplacement *)
  Oled.draw  x' y' false

let draw_apple x y : unit =
  Oled.draw x y true

(*** Fonctions de la machine d'exécution synchrone ***)

(** Initialisation du programme synchrone **)
let init_main () =  Arduboy.init ()

(** Fonction d'entrée de chaque instant synchrone **)
let input_main () =
  let l = Avr.digital_read Arduboy.button_left in
  let r = Avr.digital_read Arduboy.button_right in
  (max_size,bool_of_level l,bool_of_level r,64,32)

(** Fonction de sortie de chaque instant synchrone **)
let output_main (head,tail,nx,ny,apple_x,apple_y,win) =
  snake.(head) <- (nx,ny);
  draw_snake head tail;
  draw_apple apple_x apple_y;
  Oled.flush ();
  if win  then
    begin
      (* Gagné *)
      Arduboy.light_led Arduboy.green;
      Avr.delay 2000;
      raise Exit
    end
  else if eats_itself head tail then
    begin
      (* Perdu *)
      Arduboy.light_led Arduboy.red;
      Avr.delay 2000;
      raise Exit
    end
