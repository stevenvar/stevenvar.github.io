
(** Direction du serpent **)
type direction = South | North | East | West

(** Fonctions d'orientation : le serpent tourne à gauche et à droite **
 ** par rapport à sa direction courante **)
let left_of = function
  | South -> East
  | North -> West
  | East -> North
  | West -> South

let right_of = function
  | South -> West
  | North -> East
  | East -> South
  | West -> North

(** Modulo **)
let nmod x y =
  (x + y) mod y

(** Tirage aléatoire d'un entier **)
let new_position n = Random.int n

(** Nouvelle cordonnée en x ou en y **)
let%node new_coord (dir,max,v,dir1,dir2) ~return:n =
  n = if dir = dir1 then call nmod (v-1) max
      else if dir = dir2 then call nmod (v+1) max
      else v

(** Nouvelle position de la tête du serpent **)
let%node new_head (dir,w,h) ~return:(x,y) =
  x = new_coord (dir,w,0 ->> x,West,East);
  y = new_coord (dir,h,0 ->> y,North,South)

(** Tourner à gauche **)
let%node left (dir) ~return:ndir =
  ndir = call left_of dir

(** Tourner à droite **)
let%node right (dir) ~return:ndir =
  ndir = call right_of dir

(** Direction du serpent à partir de sa direction précédente **)
let%node direction (l,r) ~return:dir =
  pre_dir = (South ->> dir);
  dir = if l then
           (merge l (left (pre_dir [@when l])) (pre_dir [@whennot l]))
         else
           (merge r (right (pre_dir [@when r])) (pre_dir [@whennot r]))

(** Nouvelle position de la pomme **)
let%node new_apple (width,height) ~return:(a_x,a_y) =
  (a_x,a_y) = (call new_position width, call new_position height)

(** Boucle de jeu **)
let%node game_loop (max_size,left,right,width,height)
      ~return:(head,tail,new_x,new_y,apple_x,apple_y,win) =
  (new_x,new_y) = new_head (dir,width,height);
  dir = direction(left,right);
  head = (1 ->> ((head+1) mod max_size));
  eats = (apple_x = new_x && apple_y = new_y);
  (a_x,a_y) = new_apple (width [@when eats], height [@when eats]);
  apple_x = 10 ->> merge eats a_x (apple_x [@whennot eats]);
  apple_y = 10 ->> merge eats a_y  (apple_y [@whennot eats]);
  tail = merge eats ((0->>tail)[@when eats]) (0 ->> ((tail+1) mod max_size) [@whennot eats]);
  size = (1 ->> merge eats  ((size + 1) [@when eats]) (size [@whennot eats]));
  win = (size = max_size -1)

(** Front montant (pour les boutons) **)
let%node rising_edge i ~return:o =
  o = (i && (not (false ->> i)))

(** Noeud principal **)
let%node main (max_size,button1,button2,width,height) ~return:(head,tail,nx,ny,apple_x,apple_y,win) =
  left = rising_edge (button1);
  right = rising_edge (button2);
  (head,tail,nx,ny,apple_x,apple_y,win) = game_loop(max_size,left,right,width,height)
