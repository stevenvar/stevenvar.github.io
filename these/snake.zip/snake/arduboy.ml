open Avr

(** Les broches utilisées **)
let cs = PIN12
let dc = PIN4
let rst = PIN6
let button_left = PINA2
let button_right = PINA1
let button_down = PINA3
let button_up = PINA0
let button_a = PIN7
let button_b = PIN8
let blue = PIN9
let red = PIN10
let green = PIN11

(** initialisation des LED rgb à anode commune (HIGH = éteinte) **)
let init_led l =
  digital_write l HIGH

(** allumer une des LED rgb à anode commune (LOW = allumé) **)
let light_led l =
  digital_write l LOW

(** initialisation des broches **)
let boot_pins () =
  List.iter (fun x -> pin_mode x INPUT_PULLUP) [button_left; button_right; button_up;
                                                button_down];
  pin_mode button_a INPUT_PULLUP;
  pin_mode button_b INPUT_PULLUP;
  List.iter (fun x -> pin_mode x OUTPUT) [red;green;blue];
  List.iter (fun x -> pin_mode x OUTPUT) [cs;dc;rst];
  List.iter init_led [red;green;blue]

(** initialisation des broches, de la liaison SPI, et de l'écran **)
let init () =
  boot_pins ();
  Spi.begin_spi ~sck:SCK ~mosi:MOSI;
  Oled.boot ~cs:cs ~dc:dc ~rst:rst
