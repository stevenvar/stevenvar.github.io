(*** Module de gestion de la connexion SPI (Serial Peripheral Interface) ***)

open Avr

(** Initialiser la connexion SPI **)
let begin_spi ~sck ~mosi =
  set_bit SPCR MSTR;
  set_bit SPCR SPE;
  set_bit SPSR SPI2x;
  pin_mode sck OUTPUT;
  pin_mode mosi OUTPUT

(** Arrêter la connexion SPI **)
let end_spi () = clear_bit SPCR SPE

(*** Emettre des données via la connexion SPI **)
let transfer data = write_register SPDR data
