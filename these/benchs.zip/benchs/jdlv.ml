type cell = bool 

type world = { mutable tcell : cell array array ; 
               max_x : int;
               max_y : int;
               mutable gen : int ;
             }

let create_world n m = {
    tcell = Array.make_matrix n m false;
    max_x = n;
    max_y = m; 
    gen = 0
}

let get_cell w (i,j) = w.tcell.(i).(j)
let set_cell w (i,j) c = w.tcell.(i).(j) <- c
let neighbors w (x,y) =
  let r = ref 0 in
  for i=x-1 to x+1 do
    let k = (i+w.max_x) mod w.max_x in
    for j=y-1 to y+1 do
      let l = (j + w.max_y) mod w.max_y in
      if w.tcell.(k).(l) then incr r
    done
  done;
  if w.tcell.(x).(y) then decr r;
  !r

let next_gen w =
      let w2 = create_world w.max_x w.max_y in
      for i=0 to w.max_x-1 do
        for j=0 to w.max_y -1 do
          let n = neighbors w (i,j) in
          if w.tcell.(i).(j)
          then (if (n = 2) || (n = 3) then set_cell w2 (i,j) true)
          else (if n = 3 then set_cell w2 (i,j) true)
        done
      done ;
      w.tcell <- w2.tcell;
      w.gen <- w.gen + 1
      
let () =
  let a = 10 and b = 10 in
  let w = create_world a b in
  set_cell w (4,4) true;
  set_cell w (4,5) true;
  set_cell w (4,6) true;
  for i = 1 to 10000 do
    next_gen w;
  done
    


