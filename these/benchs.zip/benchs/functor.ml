module Int = struct
  type t = int
  let compare = Stdlib.compare
end

module IntSet = Set.Make(Int)

let g l =
  IntSet.min_elt (List.fold_left (fun acc x -> IntSet.add x acc) IntSet.empty l)

let _ =
  let l = List.init 50 (fun x -> x) in
  for i = 0 to 10000 do
    ignore (g l)
  done
