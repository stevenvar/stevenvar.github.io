let integrale f a b n =
  let h = (b -. a) /. (float_of_int n) in
  let rec integ x =
    if  x >= b then 0.0 else (f x) +. integ (x +. h) in
  integ  a *. h

let poly x = x *. x +. 2. *. x +. 10.

let () =
  for _i = 1 to 10000 do
      ignore (integrale poly 0.0 10.0 100)
  done
