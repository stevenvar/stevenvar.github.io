let res = ref 1.0

let rec f x =
  if x < 0.0 then !res
  else
    begin
      res := (!res)  *.  (sin 0.8) +. (cos 1.5);
      f (x -. 1.)
    end

let () =
 for i = 1 to 10000 do
   res:= 1.0;
   ignore (f 1000.1)
 done
