exception Identity

let share f x = try f x with Identity -> x

let filter f l =
  let rec fil l = match l with
    | [] -> raise Identity
    | h :: t -> if f h then h :: fil t else share fil t in
  share fil l

let () =
  let l = List.init 50 (fun x -> x) in
  for _i = 1 to 10000 do
    for _j = 1 to 10 do
      ignore (filter (fun x -> x > 25) l)
    done
  done
