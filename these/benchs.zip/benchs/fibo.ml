let rec fibo n =
  match n with
  | 0 -> 1
  | 1 -> 1
  | _ -> fibo (n-1) + fibo (n-2)

let () =
  for _i = 1 to 10000 do
    for _j = 1 to 10 do
      for k = 0 to 10 do
        ignore (fibo k)
      done
    done
  done
