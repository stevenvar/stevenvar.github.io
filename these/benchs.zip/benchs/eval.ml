type jeton = Vrai | Faux | Var of char | Non | Et | Ou | ParenG | ParenD
type formule = jeton list
type env = (char * jeton) list

exception Fail

let eval_op so sv =
  match Stack.pop so, Stack.pop sv with
                   | Non, Vrai  -> Stack.push Faux sv
                   | Non, Faux -> Stack.push Vrai sv
                   | Et, Vrai  -> ()
                   | Et, Faux  -> ignore(Stack.pop sv); Stack.push Faux sv
                   | Ou, Vrai  -> ignore(Stack.pop sv); Stack.push Vrai sv
                   | Ou, Faux  -> ()
                   | _ -> raise Fail

let one_step  sv so env j = match j with
  | Vrai | Faux -> Stack.push j sv
  | Var c -> Stack.push (List.assoc c env) sv
  | Non | Et | Ou -> Stack.push j so
  | ParenG -> ()
  | ParenD -> eval_op so sv

let eval env lj =
  let sv = Stack.create()
  and so = Stack.create()
  in
    List.iter (one_step sv so env) lj;
    while not (Stack.is_empty so) do
        eval_op so sv
    done;
    Stack.pop sv

let () =
  for i = 1 to 10000 do
      let t1 = ([],[Vrai],Vrai) in
      let t2 = ([],[Faux],Faux) in
      let t3 = ([],[Vrai; Faux; Ou], Vrai)  in
      let t4 = ([],[Vrai; Faux; Et], Faux) in
      let t5 = ([('x',Vrai)],[Var 'x'], Vrai) in
      let t6 = ([('x',Vrai)],[Var 'x'; Non], Faux) in
      let t7 = ([],[Vrai; Non],Faux) in
      let t8 = ([],[ParenG; Vrai ; Vrai; Et; ParenD], Vrai) in
      let t9 = ([],[ParenG; Faux; Vrai; Ou; ParenD; Vrai; Et], Vrai) in
      let t10 = ([('x',Vrai);('y',Faux)],[ParenG; Var 'x'; Var 'y'; Ou; ParenD; Var 'y'; Et], Faux) in
      List.iter (fun (e,x,r) -> assert (eval e x = r)) [t1;t2;t3;t4;t5;t6;t7; t8; t9 ; t10]
  done
