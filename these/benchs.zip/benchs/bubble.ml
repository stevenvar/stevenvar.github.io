let swap a i j =
  let tmp = a.(i) in
  a.(i) <- a.(j);
  a.(j) <- tmp

let bubble_sort a =
  let n = Array.length a in
  for i = 0 to n - 1 do
    for j = 0 to n - i - 2 do
      if (a.(j) > a.(j+1)) then
        swap a j (j+1)
    done
  done

let () =
  let s = 60 in
  let a = Array.make 60 0 in
    for i = 1 to 10000 do
      Array.iteri (fun i v -> a.(i) <- s-i) a;
      bubble_sort a
    done
