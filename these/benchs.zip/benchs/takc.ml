let rec tak (x, y, z) =
  if x > y then
    tak(tak (x-1, y, z), tak (y-1, z, x), tak (z-1, x, y))
  else z

let () =
  for i = 1 to 1000 do
    ignore(tak(18,12,6))
  done
