
class point x y = object
  val x = x
  val y = y
  method sym = (new point (-x) (-y))
end

let _ =
  for i = 1 to 10000 do
    for j = 1 to 10 do
      let o = new point (Random.int 100) (Random.int 100) in
      for k = 1 to 10 do
        ignore(o#sym)
      done
    done
  done
